/******/ (function() { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 450:
/***/ (function(module) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAADsAAAA7AF5KHG9AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAphJREFUWIXt10toVVcUBuDPJAotVq9SrC98gRIfTQbiC0StTsQXClYhThRF0WBbtDoQFVsVSqkTRRwIioIiRBTFoRPxRUWclVYUFR8hIFIJdVCr0cE6l9yGk5yTe+NIf7iDu/de61/7X2vvtQ8fO3pVYFvADxiGtm7wvcRBPK2AWzWaMKEM2+E4j35FR+VgIj7DhTJsW/Eao3C3pswACkJK2IDZyPL1GvfwE/5OAsg0ysIg1KMh5/rtmFI6UGkAQ8SuSlGPOlThLm5pL9I/MQIviourKgygFDNwFvPRjEdit01Y3JlRTwUwFN+KVBxFX5Ges8n415icZlhpCopoxhasxgJcxL/YhwfYXxLo/9ATCqxICOvwe/L/If7BWpzryrgSBaZgIXbhJk4m5EOwGS3iqN7sykk5ChSE1M9Fzi/jFY4nxK3oj3F4luWsuwqsxHLswR8d5i7hGAZikdjcf1kO8yowGqcxOAmiI3kRO/AL3uYhJ1uBGjRiGrbJlrQFN7BMNJxMZCmwT9x0DTnIiziCVZJuV0kAX2GqKKjuoA2nhAplBzALh7AOSzEgJ3kVNiXkF1Pma/Amy8lIUXDF+qhNgslCnTiSP2JMyq8WZ0QhzxFHObUIG0U1FyP9S3SvmbiWsv5z7BQpu40vsT5l3SvxFmjBeLxL28USnEgZX5w479NhfL64aqemOesCWzGd9kfpIPyKOzgsznEp9oumMhiPhYS9hSq7RePJg16YJLrlFtpTUBCSH+zE8CrWiFweEC+bn/ENxuYkL+Ik7qdNbBetNA8m4LduEmeiWjwgCp3MfyF2+50457kumix0/DCpxffYmMw1Yq7ofG14giu43hPkaQEQ5/gl5okKb+opsryoxl7xsPiED47375J7Alg19dwAAAAASUVORK5CYII=";

/***/ }),

/***/ 469:
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__.p + "img/bg.b366798f.png";

/***/ }),

/***/ 481:
/***/ (function(module) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAABegAAAXoBMrnI/AAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAIfSURBVFiFzde9a1RBFAXw3w2BhGAsbEywCWIjGJQIYiexs/KjERTETuwsLLQwVWrRyvwDQkrFzsJCEGzETwiIgmCRVlYiRpBrsRNcN9nd2Y3RPXDgvWHmnjNv3ty5E5mpBhExhpM4jYOYLoTVwhU8xJPMXK8KnJldWUTuoYGsZKOMme4Zv4vwOBax1odwO9dKjPG+DGAKz7ch3M7nmKoygFl8/oviG/yM2a4Gysx3QrzVxNSWBsqa/83P3m05xrcysPgPxDe4+IcBza22nb+9X64pW3RUEwuYsBmvUJdQOmMMR9raJorm1Y0OnZLMTK9EUpHIZjrEbmBsVDO9TnZwvxARjfJ8KzO/dptqRFzCXGZei4izOIHdHbpPFm1LHRy2c2/FbJeR5flORcylEc2DpQbRNtsXEbFcObYTDo74faLVuYiYj4i3mMP5iHgTEX3FaMF03wZwG6OYxw38wLFBDYz27rMJE5o/1nE8w93M/D6gASOahUQ/uIzXuImn+BIRFwfUXx3EwCecwx4cLeOvb8fASmXnjIh9eI/HuKC5DNN4OaCBFTilLg9Mlf19Dm9K2088wv7WPIBD+FgR8xTdU/EmAy1J5zUebJWIKtnA2EipXu9XfK5drS+ZeTgzz3Tr0wP3M3M9MlNJJB9sfSJu4F0PozO4Uin+DQcyc3U4CpKhKMn+e1E6FGX5UFxMhuJq1mZkRy+nUUR6Yqeu578ACE3BH1WzQfIAAAAASUVORK5CYII=";

/***/ }),

/***/ 530:
/***/ (function(module) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAdhAAAHYQGVw7i2AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAllJREFUWIXt1kuIjmEUB/Df55aRS+NOoUYuaUpSymWhLIRQyi0LWaApsrFQckmynlI2KGWaBYmlwWbkEqNGNqORIkzNxEwGMzH4LJ53mre37/59k83866nvnPN85/zf8573/zyMoHjsQxfSWI8H0e/4OoSL+INnWFCp4mPxI1aoDlWojtYc1ES++7F9V7IlTBVJYCY6Y3YaH/A7sW8ypsfse9iYKeGYIgkkkcL8chKMKpNA2fjvBMp5BZ/xUniINRgf+d/jDcZhnTwPWQ6BvfiGXmzHLGzAFixDO85g/3AR6MZlvIhWuzCQX3Abp4Qu5UQ5BBZhG37iBJ5E/sVYgq9oqCSBGnyP2Q34iNGYFxHoRCM+YTZqi8ifEyncEYQoLrkdwgykhZbXxNbm2L6mbIkL7cABrE74ruG40IHH2IRjaIvsiejDhAJrZEW1cPh0GupAqyC1bcL7P4cduIVpOIqVuCRPBwoRovOYEbN7sQv1WCp0YCAW78dZrBU6UBZWCAdN2lAHduNg5PuFhWjGETwUNKFa0IVH8nQgF1LCZA8O0uApWGvoSL4gCE/yPpBcJRHYmkjyFJPwOrLfCXPwdrgIXI0l6BWEpzHmq8PpAoqXTOBuLMEeHI7ZPZgiyG5ZBHJ9BYO3pX5BL+pjsRaswtQCH+ZvtkAhQlSF6wlfK5YXWJwgTCUTyIQOQZxu5tmXFk7K+mwbSiXwXJDaJIEuQRMqgiaZB6pFuOcPZIjVVap4NgI9wud4I0PslRLumMX+oQ8nsTNDrFmOaS+FQHcG31zZ73hdxRYfAfwDMDjJmycRDoAAAAAASUVORK5CYII=";

/***/ }),

/***/ 910:
/***/ (function(__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) {


// EXTERNAL MODULE: ./node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js
var runtime_dom_esm_bundler = __webpack_require__(751);
// EXTERNAL MODULE: ./node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
var runtime_core_esm_bundler = __webpack_require__(641);
// EXTERNAL MODULE: ./node_modules/@vue/shared/dist/shared.esm-bundler.js
var shared_esm_bundler = __webpack_require__(33);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[3]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/App.vue?vue&type=template&id=a4e08010

const _hoisted_1 = {
  class: "h-screen w-screen flex relative"
};
const _hoisted_2 = {
  class: "ebus-status"
};
const _hoisted_3 = {
  key: 1,
  class: "idle-status",
  title: "Idle 狀態"
};
const _hoisted_4 = {
  class: "text-3xl"
};
const _hoisted_5 = {
  key: 0,
  class: "text-lg mt-1"
};
const _hoisted_6 = {
  class: "flex-1 flex items-center justify-center"
};
function render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_EbusListener = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("EbusListener");
  const _component_MsgModal = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("MsgModal");
  const _component_GridMenu = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("GridMenu");
  const _component_GuiMenu = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("GuiMenu");
  return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", _hoisted_1, [$options.enableClickToAdmin ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", {
    key: 0,
    class: "admin-hotspot",
    onPointerdown: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.D$)((...args) => $options.adminTap && $options.adminTap(...args), ["prevent"]))
  }, null, 32)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), (0,runtime_core_esm_bundler/* withDirectives */.bo)((0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_2, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", null, "Ebus: " + (0,shared_esm_bundler/* toDisplayString */.v_)($data.ebusConnected ? '🟢' : '🔴'), 1)], 512), [[runtime_dom_esm_bundler/* vShow */.aG, _ctx.dev]]), (0,runtime_core_esm_bundler/* createVNode */.bF)(_component_EbusListener, {
    class: "hidden",
    modelValue: $data.ebusConnected,
    "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => $data.ebusConnected = $event),
    onEbusEventPaymentAfterHint: $options.paymentAfterHint,
    onEbusEventPaymentAfterCancelled: $options.paymentAfterCancelled,
    onEbusEventPaymentAfterTimeout: $options.paymentAfterCancelled,
    onEbusEventSysAfterHint: $options.sysAfterHint,
    onEbusEventSysAfterConfigChanged: $options.sysAfterHint,
    onEbusEventOrderAfterStart: $options.enterMENU,
    onEbusEventSessEnterSESSION: _cache[2] || (_cache[2] = $event => $data.idle = false),
    onEbusEventSessEnterIDLE: $options.enterIDLE,
    onEbusEvent: $options.messageHandler
  }, null, 8, ["modelValue", "onEbusEventPaymentAfterHint", "onEbusEventPaymentAfterCancelled", "onEbusEventPaymentAfterTimeout", "onEbusEventSysAfterHint", "onEbusEventSysAfterConfigChanged", "onEbusEventOrderAfterStart", "onEbusEventSessEnterIDLE", "onEbusEvent"]), (0,runtime_core_esm_bundler/* createVNode */.bF)(_component_MsgModal),  true ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", _hoisted_3, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", _hoisted_4, (0,shared_esm_bundler/* toDisplayString */.v_)($data.idle ? '💤' : '💡'), 1), $data.temperature !== null ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("span", _hoisted_5, " 🌡️ " + (0,shared_esm_bundler/* toDisplayString */.v_)($data.temperature) + "°C ", 1)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)])) : 0, (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_6, [(0,runtime_core_esm_bundler/* createVNode */.bF)(_component_GridMenu, {
    ref: "gridMenu",
    onClosed: $options.closed,
    onOrdered: $options.ordered,
    onPaymentSelected: $options.paymentSelected,
    onCashSelected: _ctx.cashSelected,
    onCreditcardSelected: _ctx.creditcardSelected,
    "inserted-amount": $data.insertedAmount,
    "onUpdate:insertedAmount": _cache[3] || (_cache[3] = $event => $data.insertedAmount = $event),
    "pm-ready": $data.pmReady,
    "onUpdate:pmReady": _cache[4] || (_cache[4] = $event => $data.pmReady = $event)
  }, null, 8, ["onClosed", "onOrdered", "onPaymentSelected", "onCashSelected", "onCreditcardSelected", "inserted-amount", "pm-ready"])]), (0,runtime_core_esm_bundler/* createVNode */.bF)(_component_GuiMenu, {
    items: $data.guiMenu,
    onPress: $options.onGuiMenuPress
  }, null, 8, ["items", "onPress"])]);
}
;// ./src/App.vue?vue&type=template&id=a4e08010

// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 48 modules
var axios = __webpack_require__(335);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[3]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GridMenu.vue?vue&type=template&id=5d3fd1f1&scoped=true

const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_1 = {
  key: 0,
  class: "bg-video",
  autoplay: "",
  loop: "",
  muted: "",
  playsinline: ""
};
const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_2 = ["src"];
const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_3 = {
  class: "menu-content"
};
const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_4 = ["onPointerdown"];
const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_5 = {
  class: "product-card"
};
const GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_6 = ["src", "alt"];
const _hoisted_7 = {
  key: 0,
  class: "soldout-overlay"
};
const _hoisted_8 = {
  class: "product-title"
};
const _hoisted_9 = {
  class: "product-price"
};
const _hoisted_10 = {
  key: 0,
  class: "modal-overlay"
};
const _hoisted_11 = {
  key: 0,
  class: "modal"
};
const _hoisted_12 = ["src"];
const _hoisted_13 = {
  class: "modal-title"
};
const _hoisted_14 = {
  class: "modal-price"
};
const _hoisted_15 = {
  key: 0,
  class: "modal-desc"
};
const _hoisted_16 = {
  class: "pay-list"
};
const _hoisted_17 = {
  class: "pay-list"
};
const _hoisted_18 = ["onPointerdown"];
const _hoisted_19 = ["src"];
const _hoisted_20 = {
  class: "cash-panel"
};
const _hoisted_21 = {
  class: "cash-info"
};
const _hoisted_22 = {
  class: "amount"
};
function GridMenuvue_type_template_id_5d3fd1f1_scoped_true_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_swiper_slide = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("swiper-slide");
  const _component_swiper = (0,runtime_core_esm_bundler/* resolveComponent */.g2)("swiper");
  return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", {
    class: "menu-wrapper",
    style: (0,shared_esm_bundler/* normalizeStyle */.Tr)($options.menuStyle)
  }, [$options.isVideoBg ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("video", GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_1, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("source", {
    src: $data.bgUrl,
    type: "video/mp4"
  }, null, 8, GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_2)])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_3, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("button", {
    class: "nav-btn left",
    onPointerdown: _cache[0] || (_cache[0] = (0,runtime_dom_esm_bundler/* withModifiers */.D$)((...args) => $options.goPrev && $options.goPrev(...args), ["prevent"]))
  }, [...(_cache[3] || (_cache[3] = [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", {
    class: "arrow"
  }, "←", -1)]))], 32), (0,runtime_core_esm_bundler/* createVNode */.bF)(_component_swiper, {
    modules: $options.modules,
    "slides-per-view": 1,
    "space-between": 30,
    pagination: "",
    class: "menu-swiper",
    onSwiper: $options.onSwiper
  }, {
    default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [((0,runtime_core_esm_bundler/* openBlock */.uX)(true), (0,runtime_core_esm_bundler/* createElementBlock */.CE)(runtime_core_esm_bundler/* Fragment */.FK, null, (0,runtime_core_esm_bundler/* renderList */.pI)($options.pagedProducts, (page, pageIndex) => {
      return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createBlock */.Wv)(_component_swiper_slide, {
        key: pageIndex
      }, {
        default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", {
          class: (0,shared_esm_bundler/* normalizeClass */.C4)(["grid-container", `rows-${Math.ceil(page.length / 4)}`])
        }, [((0,runtime_core_esm_bundler/* openBlock */.uX)(true), (0,runtime_core_esm_bundler/* createElementBlock */.CE)(runtime_core_esm_bundler/* Fragment */.FK, null, (0,runtime_core_esm_bundler/* renderList */.pI)(page, item => {
          return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", {
            key: item.id,
            class: "product-grid",
            onPointerdown: (0,runtime_dom_esm_bundler/* withModifiers */.D$)($event => !item.soldout && $options.ordered(item), ["prevent"])
          }, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_5, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("img", {
            src: item.img,
            alt: item.title,
            class: "product-img"
          }, null, 8, GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_6), item.soldout ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", _hoisted_7, [...(_cache[4] || (_cache[4] = [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", {
            class: "soldout-text"
          }, "售完", -1)]))])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)]), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_8, (0,shared_esm_bundler/* toDisplayString */.v_)(item.title), 1), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_9, (0,shared_esm_bundler/* toDisplayString */.v_)(item.price) + " 元", 1)], 40, GridMenuvue_type_template_id_5d3fd1f1_scoped_true_hoisted_4);
        }), 128))], 2)]),
        _: 2
      }, 1024);
    }), 128))]),
    _: 1
  }, 8, ["modules", "onSwiper"]), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("button", {
    class: "nav-btn right",
    onPointerdown: _cache[1] || (_cache[1] = (0,runtime_dom_esm_bundler/* withModifiers */.D$)((...args) => $options.goNext && $options.goNext(...args), ["prevent"]))
  }, [...(_cache[5] || (_cache[5] = [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", {
    class: "arrow"
  }, "→", -1)]))], 32)]), (0,runtime_core_esm_bundler/* createVNode */.bF)(runtime_dom_esm_bundler/* Transition */.eB, {
    name: "fade",
    mode: "out-in"
  }, {
    default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [$data.selected ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", _hoisted_10, [(0,runtime_core_esm_bundler/* createVNode */.bF)(runtime_dom_esm_bundler/* Transition */.eB, {
      name: "zoom",
      mode: "out-in"
    }, {
      default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [$data.selected ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", _hoisted_11, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("button", {
        class: "modal-close",
        onPointerdown: _cache[2] || (_cache[2] = (0,runtime_dom_esm_bundler/* withModifiers */.D$)((...args) => $options.closeModal && $options.closeModal(...args), ["prevent"]))
      }, "✕", 32), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("img", {
        src: $data.selected.img,
        class: "modal-img"
      }, null, 8, _hoisted_12), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("h3", _hoisted_13, (0,shared_esm_bundler/* toDisplayString */.v_)($data.selected.title), 1), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("p", _hoisted_14, "售價：" + (0,shared_esm_bundler/* toDisplayString */.v_)($data.selected.price) + " 元", 1), $data.selected.desc ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("p", _hoisted_15, (0,shared_esm_bundler/* toDisplayString */.v_)($data.selected.desc), 1)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), (0,runtime_core_esm_bundler/* withDirectives */.bo)((0,runtime_core_esm_bundler/* createElementVNode */.Lk)("p", _hoisted_16, "開啟支付選單，請稍後…", 512), [[runtime_dom_esm_bundler/* vShow */.aG, !$props.pmReady]]), (0,runtime_core_esm_bundler/* withDirectives */.bo)((0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_17, [_cache[6] || (_cache[6] = (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("p", null, "請選用以下支付方式：", -1)), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("ol", null, [((0,runtime_core_esm_bundler/* openBlock */.uX)(true), (0,runtime_core_esm_bundler/* createElementBlock */.CE)(runtime_core_esm_bundler/* Fragment */.FK, null, (0,runtime_core_esm_bundler/* renderList */.pI)($data.payOptions, (opt, method) => {
        return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("li", {
          key: method,
          class: "pay-item",
          onPointerdown: (0,runtime_dom_esm_bundler/* withModifiers */.D$)($event => $options.selectPay(method), ["prevent"])
        }, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("img", {
          src: $options.payIcon(method),
          class: "pay-icon"
        }, null, 8, _hoisted_19), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", null, (0,shared_esm_bundler/* toDisplayString */.v_)($options.payText(method)), 1)], 40, _hoisted_18);
      }), 128))])], 512), [[runtime_dom_esm_bundler/* vShow */.aG, !$data.cashSelected && $props.pmReady]]), (0,runtime_core_esm_bundler/* withDirectives */.bo)((0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_20, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("div", _hoisted_21, [_cache[7] || (_cache[7] = (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", {
        class: "label"
      }, "請投入現金，已投入金額：", -1)), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", _hoisted_22, (0,shared_esm_bundler/* toDisplayString */.v_)($props.insertedAmount) + " 元", 1)]), _cache[8] || (_cache[8] = (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("p", {
        class: "cash-warning"
      }, "為避免吃錢，請一個一個投入！", -1))], 512), [[runtime_dom_esm_bundler/* vShow */.aG, $data.cashSelected]])])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)]),
      _: 1
    })])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)]),
    _: 1
  })], 4);
}
;// ./src/components/GridMenu.vue?vue&type=template&id=5d3fd1f1&scoped=true

// EXTERNAL MODULE: ./node_modules/swiper/swiper-vue.mjs + 3 modules
var swiper_vue = __webpack_require__(434);
// EXTERNAL MODULE: ./node_modules/swiper/modules/index.mjs + 27 modules
var modules = __webpack_require__(839);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GridMenu.vue?vue&type=script&lang=js






/* harmony default export */ var GridMenuvue_type_script_lang_js = ({
  name: 'GridMenu',
  components: {
    Swiper: swiper_vue/* Swiper */.RC,
    SwiperSlide: swiper_vue/* SwiperSlide */.qr
  },
  props: {
    insertedAmount: Number,
    pmReady: Boolean
  },
  data() {
    return {
      payOptions: null,
      products: [],
      swiperInstance: null,
      selected: null,
      cashSelected: false,
      bgUrl: null
    };
  },
  computed: {
    isVideoBg() {
      return this.bgUrl && /\.(mp4|webm)$/i.test(this.bgUrl);
    },
    menuStyle() {
      return {
        backgroundImage: this.bgUrl ? `url(${this.bgUrl})` : 'none',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      };
    },
    pagedProducts() {
      const size = 16;
      const pages = [];
      for (let i = 0; i < this.products.length; i += size) {
        pages.push(this.products.slice(i, i + size));
      }
      return pages;
    },
    modules() {
      return [modules/* Navigation */.Vx, modules/* Pagination */.dK];
    }
  },
  mounted() {
    this.loadProducts();
    this.loadBackground();
  },
  methods: {
    async loadBackground() {
      const params = new URLSearchParams(window.location.search);
      const bgFromQuery = params.get('bg');
      if (bgFromQuery) {
        this.bgUrl = bgFromQuery;
        return;
      }
      const localBg = `${window.location.origin}/media/gui/bg.png`;
      const fallback = __webpack_require__(469);
      const found = await this.checkImage(localBg);
      this.bgUrl = found ? localBg : fallback;
    },
    // 判斷圖片是否存在
    checkImage(src) {
      return new Promise(resolve => {
        const img = new Image();
        img.onload = () => resolve(true);
        img.onerror = () => resolve(false);
        img.src = src + `?t=${Date.now()}`;
        // 加 timestamp 避免 cache 導致判斷錯誤
      });
    },
    async loadProducts() {
      try {
        // 解析 URL 參數
        const urlParams = new URLSearchParams(window.location.search);
        const restParam = urlParams.get('rest');

        // 決定要呼叫的 API URL
        const restURL = restParam ? decodeURIComponent(restParam) : `${window.location.origin}/app/rest/stock.cgi`;
        const res = await axios/* default */.A.get(`${restURL}/app/rest/stock.cgi`);
        this.products = res.data;
      } catch (err) {
        console.error('載入商品失敗', err);
      }
    },
    selectPay(pm) {
      if (pm === 'cash') {
        this.cashSelected = true;
      }
      this.$emit('paymentSelected', pm);
    },
    onSwiper(swiper) {
      this.swiperInstance = swiper;
    },
    goPrev() {
      this.swiperInstance?.slidePrev();
    },
    goNext() {
      this.swiperInstance?.slideNext();
    },
    ordered(item) {
      this.openModal(item);
      this.$emit('ordered', item);
    },
    openModal(item) {
      this.selected = item;
    },
    closeModal() {
      this.selected = null;
      this.cashSelected = false;
      this.$emit('closed');
    },
    payText(method) {
      switch (method) {
        case "cash":
          return "現金 - 點此進行現金支付";
        case "creditcard":
          return "信用卡 - 點此進行信用卡支付";
        case "easycard":
          return "電子票卷 - 點此使用悠遊卡/一卡通";
        case "isc_linepay":
          return "電子支付 - 點此進行電子支付，將支付二維碼對準條碼掃描器";
        default:
          return method;
      }
    },
    payIcon(method) {
      switch (method) {
        case "cash":
          return __webpack_require__(481);
        case "creditcard":
          return __webpack_require__(450);
        case "easycard":
          return __webpack_require__(450);
        case "isc_linepay":
          return __webpack_require__(530);
        default:
          return __webpack_require__(530);
      }
    }
  }
});
;// ./src/components/GridMenu.vue?vue&type=script&lang=js
 
;// ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GridMenu.vue?vue&type=style&index=0&id=5d3fd1f1&scoped=true&lang=css
// extracted by mini-css-extract-plugin

;// ./src/components/GridMenu.vue?vue&type=style&index=0&id=5d3fd1f1&scoped=true&lang=css

// EXTERNAL MODULE: ./node_modules/vue-loader/dist/exportHelper.js
var exportHelper = __webpack_require__(262);
;// ./src/components/GridMenu.vue




;


const __exports__ = /*#__PURE__*/(0,exportHelper/* default */.A)(GridMenuvue_type_script_lang_js, [['render',GridMenuvue_type_template_id_5d3fd1f1_scoped_true_render],['__scopeId',"data-v-5d3fd1f1"]])

/* harmony default export */ var GridMenu = (__exports__);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[3]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GuiMenu.vue?vue&type=template&id=a88d8e3c&scoped=true

const GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_1 = {
  key: 0,
  class: "gui-menu"
};
const GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_2 = ["onPointerdown"];
const GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_3 = {
  key: 0,
  class: "gui-menu-icon"
};
const GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_4 = {
  class: "gui-menu-label"
};
function GuiMenuvue_type_template_id_a88d8e3c_scoped_true_render(_ctx, _cache, $props, $setup, $data, $options) {
  return $props.items.length ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_1, [((0,runtime_core_esm_bundler/* openBlock */.uX)(true), (0,runtime_core_esm_bundler/* createElementBlock */.CE)(runtime_core_esm_bundler/* Fragment */.FK, null, (0,runtime_core_esm_bundler/* renderList */.pI)($props.items, func => {
    return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("button", {
      key: func.id,
      class: "gui-menu-btn",
      onPointerdown: (0,runtime_dom_esm_bundler/* withModifiers */.D$)($event => $options.onPress(func), ["prevent"])
    }, [func.icon ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("span", GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.v_)(func.icon), 1)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("span", GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_4, (0,shared_esm_bundler/* toDisplayString */.v_)(func.label), 1)], 40, GuiMenuvue_type_template_id_a88d8e3c_scoped_true_hoisted_2);
  }), 128))])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true);
}
;// ./src/components/GuiMenu.vue?vue&type=template&id=a88d8e3c&scoped=true

// EXTERNAL MODULE: ./node_modules/mqtt/dist/mqtt.esm.js
var mqtt_esm = __webpack_require__(61);
;// ./src/services/ebusService.js
// src/common/services/EbusService.js

class EbusService {
  constructor() {
    this.client = null;
    this.listeners = [];
    this.connected = false;
  }
  connect(customUrl = null) {
    if (this.client) return;
    const options = {
      connectTimeout: 4000,
      clientId: 'vue-ebus-' + Math.random().toString(16).substring(2, 8)
    };
    const defaultUrl = `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.hostname}:9001/mqtt`;
    const url = customUrl || defaultUrl;
    console.log(`[EbusService] Connecting to ${url}`);
    this.client = mqtt_esm/* default */.A.connect(url, options);
    this.client.on('connect', () => {
      this.connected = true;
      this.client.subscribe('topic/app', err => {
        if (!err) {
          console.log('[EbusService] Subscribed topic/app');
        }
      });
    });
    this.client.on('message', (topic, message) => {
      try {
        const ev = JSON.parse(message.toString());
        if (ev && ev.e) {
          this.notifyAll(ev);
        }
      } catch (error) {
        console.error('MQTT parse error:', message.toString());
        console.error('Error detail:', error);
      }
    });
    this.client.on('error', err => {
      console.error('[EbusService] Error:', err);
    });
    this.client.on('close', () => {
      this.connected = false;
    });
  }
  onEvent(callback) {
    if (typeof callback === 'function') {
      this.listeners.push(callback);
    }
  }
  notifyAll(event) {
    this.listeners.forEach(cb => cb(event));
  }
  send(ev, arg) {
    if (this.client && this.connected) {
      const trig = 'queue/app';
      const e = {
        e: ev
      };
      if (arg) {
        e.arg = arg;
      }
      const msg = JSON.stringify(e);
      this.client.publish(trig, msg);
      console.log(`[EbusService] 發送至 ${trig}：`, msg);
    } else {
      console.warn('[EbusService] 無法發送：尚未連線');
    }
  }
}
/* harmony default export */ var ebusService = (new EbusService());
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GuiMenu.vue?vue&type=script&lang=js

/* harmony default export */ var GuiMenuvue_type_script_lang_js = ({
  name: 'GuiMenu',
  props: {
    /**
     * gui_menu 功能按鈕列表
     * 每個項目結構:
     * {
     *   id: String,        // 唯一識別碼，例如 'exchange'
     *   label: String,     // 顯示文字，例如 '兌鈔'
     *   icon: String,      // 按鈕圖示 (emoji 或文字)
     *   event: String,     // (optional) 點擊時發送的 ebus 事件名稱
     *   arg: Object,       // (optional) 事件附帶參數
     * }
     */
    items: {
      type: Array,
      default: () => []
    }
  },
  emits: ['press'],
  methods: {
    onPress(func) {
      // 發出統一的 press 事件，帶回整個 func 物件
      this.$emit('press', func);

      // 若有定義 ebus event，則透過 ebusService 發送
      if (func.event) {
        ebusService.send(func.event, func.arg || {});
      }
    }
  }
});
;// ./src/components/GuiMenu.vue?vue&type=script&lang=js
 
;// ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/GuiMenu.vue?vue&type=style&index=0&id=a88d8e3c&scoped=true&lang=css
// extracted by mini-css-extract-plugin

;// ./src/components/GuiMenu.vue?vue&type=style&index=0&id=a88d8e3c&scoped=true&lang=css

;// ./src/components/GuiMenu.vue




;


const GuiMenu_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(GuiMenuvue_type_script_lang_js, [['render',GuiMenuvue_type_template_id_a88d8e3c_scoped_true_render],['__scopeId',"data-v-a88d8e3c"]])

/* harmony default export */ var GuiMenu = (GuiMenu_exports_);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[3]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/MsgModal.vue?vue&type=template&id=06713029&scoped=true

const MsgModalvue_type_template_id_06713029_scoped_true_hoisted_1 = {
  key: 0,
  class: "modal"
};
const MsgModalvue_type_template_id_06713029_scoped_true_hoisted_2 = {
  key: 0,
  class: "modal-content"
};
const MsgModalvue_type_template_id_06713029_scoped_true_hoisted_3 = {
  key: 1,
  class: "modal-content"
};
const MsgModalvue_type_template_id_06713029_scoped_true_hoisted_4 = {
  key: 3,
  class: "btn-group"
};
function MsgModalvue_type_template_id_06713029_scoped_true_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", null, [(0,runtime_core_esm_bundler/* createVNode */.bF)(runtime_dom_esm_bundler/* Transition */.eB, {
    name: "fade"
  }, {
    default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [$data.visible ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", {
      key: 0,
      class: "modal-overlay",
      onMousedown: _cache[0] || (_cache[0] = (...args) => $options.handleOverlayClick && $options.handleOverlayClick(...args))
    }, null, 32)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)]),
    _: 1
  }), (0,runtime_core_esm_bundler/* createVNode */.bF)(runtime_dom_esm_bundler/* Transition */.eB, {
    name: "zoom"
  }, {
    default: (0,runtime_core_esm_bundler/* withCtx */.k6)(() => [$data.visible ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", MsgModalvue_type_template_id_06713029_scoped_true_hoisted_1, [$data.mode !== 'yesno' ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", MsgModalvue_type_template_id_06713029_scoped_true_hoisted_2, (0,shared_esm_bundler/* toDisplayString */.v_)($data.message), 1)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), $data.mode === 'yesno' ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", MsgModalvue_type_template_id_06713029_scoped_true_hoisted_3, (0,shared_esm_bundler/* toDisplayString */.v_)($data.message), 1)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), $data.mode === 'info' ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("button", {
      key: 2,
      class: "modal-btn",
      onMousedown: _cache[1] || (_cache[1] = (...args) => $options.close && $options.close(...args))
    }, "關閉", 32)) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true), $data.mode === 'yesno' ? ((0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div", MsgModalvue_type_template_id_06713029_scoped_true_hoisted_4, [(0,runtime_core_esm_bundler/* createElementVNode */.Lk)("button", {
      class: "modal-btn yes",
      onMousedown: _cache[2] || (_cache[2] = (...args) => $options.yes && $options.yes(...args))
    }, "是", 32), (0,runtime_core_esm_bundler/* createElementVNode */.Lk)("button", {
      class: "modal-btn no",
      onMousedown: _cache[3] || (_cache[3] = (...args) => $options.no && $options.no(...args))
    }, "否", 32)])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)])) : (0,runtime_core_esm_bundler/* createCommentVNode */.Q3)("", true)]),
    _: 1
  })]);
}
;// ./src/components/MsgModal.vue?vue&type=template&id=06713029&scoped=true

// EXTERNAL MODULE: ./node_modules/mitt/dist/mitt.mjs
var mitt = __webpack_require__(380);
;// ./src/services/modalService.js
// modalService.js


// 建立一個全局 event bus
const modalBus = (0,mitt/* default */.A)();
modalBus.once = function (ev, cb) {
  const handler = () => {
    cb();
    modalBus.off(ev, handler);
  };
  modalBus.on(ev, handler);
  return modalBus;
};

// 專案專用的 ModalService
const ModalService = {
  showLocked(message = '處理中，請稍候…') {
    modalBus.emit('showLocked', message);
    return modalBus;
  },
  showInfo({
    message = '',
    delay = 3000,
    callback = null
  } = {}) {
    modalBus.emit('showInfo', {
      message,
      delay
    });
    if (typeof callback === 'function') {
      modalBus.once('closed', callback); // 確保只執行一次
    }
    return modalBus;
  },
  showYesNo(message = '再次確認…', yes, no) {
    modalBus.emit('showYesNo', {
      message,
      yes,
      no
    });
    return modalBus;
  },
  close() {
    modalBus.emit('closeModal');
    return modalBus;
  }
};
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/MsgModal.vue?vue&type=script&lang=js

/* harmony default export */ var MsgModalvue_type_script_lang_js = ({
  name: 'MsgModal',
  data() {
    return {
      timer: null,
      visible: false,
      message: '',
      mode: 'info',
      // 'locked', 'info', 'yesno'
      delay: 3000,
      yesCallback: null,
      noCallback: null
    };
  },
  methods: {
    showInfo(message = '', delay = 3000) {
      this.mode = 'info';
      this.message = message;
      this.visible = true;
      this.delay = delay;
      this._clearTimer();
      this.timer = setTimeout(() => {
        this.close();
      }, delay);
    },
    showLocked(message = '') {
      this.mode = 'locked';
      this._clearTimer();
      this.message = message;
      this.visible = true;
    },
    showYesNo({
      message,
      yes,
      no
    }) {
      this.mode = 'yesno';
      this.message = message;
      this.yesCallback = yes;
      this.noCallback = no;
      this.visible = true;
    },
    yes() {
      if (typeof this.yesCallback === 'function') this.yesCallback();
      this.visible = false;
    },
    no() {
      if (typeof this.noCallback === 'function') this.noCallback();
      this.visible = false;
    },
    close() {
      this._clearTimer();
      this.visible = false;
      modalBus.emit('closed');
    },
    handleOverlayClick() {
      if (this.mode === 'info') {
        this.close();
      }
    },
    _clearTimer() {
      if (this.timer) {
        clearTimeout(this.timer);
        this.timer = null;
      }
    }
  },
  created() {
    modalBus.on('showLocked', this.showLocked);
    modalBus.on('showInfo', info => {
      this.showInfo(info.message, info.delay);
    });
    modalBus.on('showYesNo', info => {
      this.showYesNo(info);
    });
    modalBus.on('closeModal', this.close);
  }
});
;// ./src/components/MsgModal.vue?vue&type=script&lang=js
 
;// ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/MsgModal.vue?vue&type=style&index=0&id=06713029&scoped=true&lang=css
// extracted by mini-css-extract-plugin

;// ./src/components/MsgModal.vue?vue&type=style&index=0&id=06713029&scoped=true&lang=css

;// ./src/components/MsgModal.vue




;


const MsgModal_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(MsgModalvue_type_script_lang_js, [['render',MsgModalvue_type_template_id_06713029_scoped_true_render],['__scopeId',"data-v-06713029"]])

/* harmony default export */ var MsgModal = (MsgModal_exports_);
;// ./src/mixins/init.js
/* harmony default export */ var init = ({
  data() {
    return {
      dev: false // 預設不顯示
    };
  },
  created() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('dev')) {
      this.dev = true;
      document.body.classList.add('dev-mode');
    }
  },
  mounted() {
    document.addEventListener("contextmenu", e => e.preventDefault());
    document.addEventListener('dragstart', function (event) {
      event.preventDefault();
    });
  }
});
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/templateLoader.js??ruleSet[1].rules[3]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/EbusListener.vue?vue&type=template&id=f71145b4

function EbusListenervue_type_template_id_f71145b4_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (0,runtime_core_esm_bundler/* openBlock */.uX)(), (0,runtime_core_esm_bundler/* createElementBlock */.CE)("div");
}
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/components/EbusListener.vue?vue&type=script&lang=js

/* harmony default export */ var EbusListenervue_type_script_lang_js = ({
  name: 'EbusListener',
  props: {
    modelValue: {
      type: Boolean,
      default: false
    },
    ebusUrl: {
      type: String,
      required: false
    }
  },
  mounted() {
    // 解析 URL ?ebus=xxx
    const params = new URLSearchParams(window.location.search);
    const urlParam = params.get("ebus");

    // 優先順序：URL > prop > null
    const finalUrl = urlParam || this.ebusUrl || null;
    ebusService.connect(finalUrl);
    const emitConnected = mode => {
      this.$emit('update:modelValue', mode);
    };

    // 監聽ebusService的event，並用$emit往外發
    ebusService.onEvent(ev => {
      this.$emit('ebus-event', ev);
      if (ev.e) {
        const en = ev.e.replace(/[/_]/g, '-');
        this.$emit(`ebus-event-${en}`, ev);
      }
    });
    if (ebusService.client) {
      ebusService.client.on('close', () => emitConnected(false));
      ebusService.client.on('connect', () => emitConnected(true));
    }
  }
});
;// ./src/components/EbusListener.vue?vue&type=script&lang=js
 
;// ./src/components/EbusListener.vue




;
const EbusListener_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(EbusListenervue_type_script_lang_js, [['render',EbusListenervue_type_template_id_f71145b4_render]])

/* harmony default export */ var EbusListener = (EbusListener_exports_);
;// ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js??clonedRuleSet-40.use[1]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/App.vue?vue&type=script&lang=js








/* harmony default export */ var Appvue_type_script_lang_js = ({
  components: {
    MsgModal: MsgModal,
    EbusListener: EbusListener,
    GridMenu: GridMenu,
    GuiMenu: GuiMenu
  },
  mixins: [init],
  data() {
    return {
      ebusConnected: false,
      showModal: false,
      insertedAmount: 0,
      pmReady: false,
      idle: true,
      pendingOrder: null,
      temperature: null,
      guiMenu: [],
      // click-to-admin 設定
      adminTapCount: 0,
      adminTapTimer: null,
      adminTapWindowMs: 2000,
      // 多快算「快速點擊」
      adminTapTarget: 6
    };
  },
  computed: {
    enableClickToAdmin() {
      const params = new URLSearchParams(window.location.search);
      // 支援 ?clicktoadmin 或 &clicktoadmin
      return params.has('clicktoadmin');
    }
  },
  methods: {
    adminTap() {
      // 安全保護：沒開就不做
      if (!this.enableClickToAdmin) return;
      // 第一下開始計時
      if (this.adminTapCount === 0) {
        if (this.adminTapTimer) clearTimeout(this.adminTapTimer);
        this.adminTapTimer = setTimeout(() => {
          this.adminTapCount = 0;
          this.adminTapTimer = null;
        }, this.adminTapWindowMs);
      }
      this.adminTapCount += 1;
      if (this.adminTapCount >= this.adminTapTarget) {
        // 達標：送出事件
        ebusService.send('sys/sys_admin');
        // 重置
        this.adminTapCount = 0;
        if (this.adminTapTimer) clearTimeout(this.adminTapTimer);
        this.adminTapTimer = null;
      }
    },
    loadCustomCss() {
      const params = new URLSearchParams(window.location.search);
      const cssFromQuery = params.get('css');
      const cssUrl = cssFromQuery ? cssFromQuery : `${window.location.origin}/media/gui/custom.css`;
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = cssUrl + `?t=${Date.now()}`; // 加 timestamp 防止 cache

      link.onload = () => {
        console.log("Custom CSS loaded:", cssUrl);
      };
      link.onerror = () => {
        console.warn("No custom.css found, using default styles.");
      };
      document.head.appendChild(link);
    },
    sysAfterHint(e) {
      if (e.e === "sys/after_config_changed" && e.arg?.act === "stock_changed") {
        this.$refs.gridMenu.loadProducts();
      } else if (e.e === "sys/after_hint") {
        if (e.arg?.stock_updated) {
          this.$refs.gridMenu.loadProducts();
        } else if (e.arg?.tempreport) {
          this.temperature = e.arg.tempreport.t;
        }
      }
    },
    async checkIdleStatus() {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const restParam = urlParams.get('rest');
        const restURL = restParam ? decodeURIComponent(restParam) : `${window.location.origin}/app/rest`;
        const res = await axios/* default */.A.get(`${restURL}/app/rest/stat.cgi`);
        if (res.data && res.data.sess) {
          this.idle = res.data.sess.toUpperCase() === 'IDLE';
          console.log('[checkIdleStatus] sess =', res.data.sess, '→ idle =', this.idle);
        } else {
          console.warn('[checkIdleStatus] stat.cgi 格式不明：', res.data);
        }
      } catch (err) {
        console.error('讀取 stat.cgi 錯誤：', err);
      }
    },
    messageHandler(e) {
      if (this.dev) console.log(e);
      if (e.arg?.info !== undefined) {
        if (e.arg?.final) {
          let cb = () => {
            this.$refs.gridMenu.closeModal();
          };
          ModalService.showInfo({
            message: e.arg.info,
            callback: cb
          });
        } else {
          ModalService.showInfo({
            message: e.arg.info
          });
        }
      } else if (e.arg?.lock != undefined) {
        ModalService.showLocked(e.arg.lock);
      }
    },
    enterMENU(e) {
      if (e.to === 'MENU' && this.pendingOrder) {
        ebusService.send('order/ordered', {
          "p_id": this.pendingOrder.id
        });
        this.pendingOrder = null;
      }
    },
    enterIDLE() {
      this.idle = true;
      this.$refs.gridMenu.closeModal();
    },
    ordered(item) {
      if (this.idle) {
        ebusService.send('sess/session_begin');
        this.pendingOrder = item;
      } else {
        // 否則立即送出
        ebusService.send('order/ordered', {
          "p_id": item.id
        });
        this.pendingOrder = null;
      }
    },
    paymentAfterHint(e) {
      if (e.arg?.payment_method) {
        this.$refs.gridMenu.payOptions = e.arg.payment_method;
        this.pmReady = true;
        const methods = Object.keys(e.arg.payment_method);
        if (methods.length === 1 && methods[0] === 'cash') {
          console.log('[GridMenu] 自動選擇現金支付');
          this.$refs.gridMenu.selectPay('cash');
        }
      }
      if (e.arg?.paid) {
        this.insertedAmount = e.arg.paid;
      }
    },
    paymentAfterCancelled() {
      ModalService.close();
      this.$refs.gridMenu.closeModal();
    },
    paymentSelected(pm) {
      if (pm === 'creditcard') {
        ModalService.showLocked('請將信用卡靠近卡機進行感應');
      } else if (pm === 'isc_linepay') {
        ModalService.showLocked('請出示Linepay支付條碼，靠近掃碼器');
      }
      ebusService.send("payment/input", {
        "method": pm,
        "payment_method": {
          [pm]: {}
        }
      });
    },
    closed() {
      this.insertedAmount = 0;
      this.pmReady = false;
      ebusService.send("payment/cancelled");
    },
    async loadGuiMenu() {
      const urlParams = new URLSearchParams(window.location.search);
      const restParam = urlParams.get('rest');
      const restURL = restParam ? decodeURIComponent(restParam) : `${window.location.origin}`;
      try {
        const res = await axios/* default */.A.get(`${restURL}/app/rest/get_config.cgi`);
        if (res.data && Array.isArray(res.data.gui_menu)) {
          this.guiMenu = res.data.gui_menu;
          console.log('[loadGuiMenu] loaded', this.guiMenu.length, 'items');
        } else {
          console.warn('[loadGuiMenu] gui_menu not found, using demo');
          this.guiMenu = this.demoGuiMenu();
        }
      } catch (err) {
        console.warn('[loadGuiMenu] get_config.cgi failed, using demo:', err.message);
        this.guiMenu = this.demoGuiMenu();
      }
    },
    onGuiMenuPress(func) {
      alert(JSON.stringify(func, null, 2));
    },
    demoGuiMenu() {
      return [
        // { id: 'exchange',  label: '兌鈔', icon: '💵', event: 'order/ordered',  arg: {func:'exchange'} },
        // { id: 'cart',      label: '購物車', icon: '🛒', event: 'order/hint',     arg: {func:'cart'} },
        // { id: 'language',  label: '語言', icon: '🌐' },
        // { id: 'member',    label: '會員', icon: '👤', event: 'order/hint',     arg: {func:'member'} },
      ];
    }
  },
  async mounted() {
    this.loadCustomCss();
    this.$nextTick(() => {
      if (!this.ebusConnected && ebusService.connected) {
        this.ebusConnected = true;
      }
    });
    // 防止兩指縮放
    document.addEventListener('touchstart', function (e) {
      if (e.touches.length > 1) {
        e.preventDefault();
      }
    }, {
      passive: false
    });
    await this.checkIdleStatus();
    await this.loadGuiMenu();
  },
  beforeUnmount() {
    if (this.adminTapTimer) clearTimeout(this.adminTapTimer);
  }
});
;// ./src/App.vue?vue&type=script&lang=js
 
;// ./node_modules/mini-css-extract-plugin/dist/loader.js??clonedRuleSet-12.use[0]!./node_modules/css-loader/dist/cjs.js??clonedRuleSet-12.use[1]!./node_modules/vue-loader/dist/stylePostLoader.js!./node_modules/postcss-loader/dist/cjs.js??clonedRuleSet-12.use[2]!./node_modules/vue-loader/dist/index.js??ruleSet[0].use[0]!./src/App.vue?vue&type=style&index=0&id=a4e08010&lang=css
// extracted by mini-css-extract-plugin

;// ./src/App.vue?vue&type=style&index=0&id=a4e08010&lang=css

;// ./src/App.vue




;


const App_exports_ = /*#__PURE__*/(0,exportHelper/* default */.A)(Appvue_type_script_lang_js, [['render',render]])

/* harmony default export */ var App = (App_exports_);
;// ./src/main.js


// URL 切換 log 開關
const urlParams = new URLSearchParams(window.location.search);
const logOff = urlParams.get('log') === 'off';
if (logOff) {
  console.log = () => {};
  console.warn = () => {};
  console.info = () => {};
}

// URL 切換 UI 效果開關
const uiOff = urlParams.get('uieffect') === 'off';
if (uiOff) {
  // 全域停用 CSS 動畫
  const style = document.createElement('style');
  style.innerHTML = `
    * {
      animation: none !important;
      transition: none !important;
    }
    .product-card:hover,
    .product-img:hover {
      transform: none !important;
    }
  `;
  document.head.appendChild(style);
}
(0,runtime_dom_esm_bundler/* createApp */.Ef)(App).mount('#app');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/amd options */
/******/ 	!function() {
/******/ 		__webpack_require__.amdO = {};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	!function() {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = function(result, chunkIds, fn, priority) {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var chunkIds = deferred[i][0];
/******/ 				var fn = deferred[i][1];
/******/ 				var priority = deferred[i][2];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every(function(key) { return __webpack_require__.O[key](chunkIds[j]); })) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	!function() {
/******/ 		__webpack_require__.p = "";
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	!function() {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			524: 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = function(chunkId) { return installedChunks[chunkId] === 0; };
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = function(parentChunkLoadingFunction, data) {
/******/ 			var chunkIds = data[0];
/******/ 			var moreModules = data[1];
/******/ 			var runtime = data[2];
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some(function(id) { return installedChunks[id] !== 0; })) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkgui_vend"] = self["webpackChunkgui_vend"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	}();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, [504], function() { return __webpack_require__(910); })
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=app.6bd51a7b.js.map